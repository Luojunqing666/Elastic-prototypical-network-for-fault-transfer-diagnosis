Table 1:
The re-organization of CWRU bearing dataset.

|Class label | Bearing condition | Fault diameter (mil) | Load(hp)|
|:----:|:----:|:----:|:----:|
|0	|NC	|0	|0,1,2,3|
|1	|IF	|7	|0,1,2,3|
|2	|IF	|14 |0,1,2,3|
|3 |IF	|21	|0,1,2,3|
|4	|OF	|7	|0,1,2,3|
|5 |OF	|14	|0,1,2,3|
|6 |OF	|21	|0,1,2,3|
|7 |RoF	|7	|0,1,2,3|
|8	|RoF	|14	|0,1,2,3|
|9	|RoF	|21	|0,1,2,3|
